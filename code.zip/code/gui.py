
import tkinter as tk
import webbrowser
import UIC_SEARCH_ENGINE as use 

import ast
import nltk
from nltk.stem import PorterStemmer
import os
import re
import string
from collections import Counter
import numpy as np
import math
import sys
import json
import operator
import collections

class Search_Gui(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.checkbox_val = tk.IntVar()
        self.checkbox_val.set(0)
        
        self.heading_label = tk.Label(self, text = "Type your query")
        self.entry = tk.Entry(self)
        self.checkBox = tk.Checkbutton(self, text = "Use Pagerank Algorithm", variable = self.checkbox_val, onvalue = 1, offvalue = 0, command = self.checkbox_action)

        self.go_button = tk.Button(self, text = "Go", command = self.search_button_action)
        self.next_button = tk.Button(self, text = "Next", command = self.next_button_action)
        self.prev_button = tk.Button(self, text = "Prev", command = self.prev_button_action)
        
        self.heading_label.pack()
        self.entry.pack()
        self.checkBox.pack() 
        self.go_button.pack()
        self.next_button.pack()
        self.prev_button.pack()
        self.label_list = []
        
        file_inverted_index = open("inv_index_last.txt", "r",encoding="utf8")
        contents_inverted_index = file_inverted_index.read()
        self.InvertedIndex = ast.literal_eval(contents_inverted_index)
        
        file_doc_length = open("doc_length_last.txt", "r")
        contents_doc_length = file_doc_length.read()
        self.document_lengths = ast.literal_eval(contents_doc_length)
        
        file_maxcount = open("maxcount_dict.txt", "r")
        maxcount_contents = file_maxcount.read()
        self.maxcount_dict = ast.literal_eval(maxcount_contents)
        
        dict_doc = open("url_index_dict_last.txt", "r")
        contents_dict = dict_doc.read()
        self.dict_url = ast.literal_eval(contents_dict)
        
        file_pagerank = open("page_rank_dict.txt", "r",encoding="utf8")
        content = file_pagerank.read()
        self.pagerank = ast.literal_eval(content)
        
        sorted_x = sorted(self.pagerank.items(), key=operator.itemgetter(1), reverse=True)
        self.sorted_dict = collections.OrderedDict(sorted_x)
        
        self.current_page_index = 0
        self.elems_per_page = 10
        self.data = []
        self.is_pagerank_use = False
        self.cosine_data = []
        self.pagerank_data = []
        
        self.bind('<Return>', self.search_button_action_enter_button)

    def search_button_action(self):
        for label in self.label_list:
            label.pack_forget()
        search_string = self.entry.get()
        print(search_string)
        if len(search_string) > 0:
            # data = dummy.dummy()
            # for url, v in data.items():
            #     url_label = tk.Label(self, text = url)
            #     url_label.pack()
            #     url_label.bind("<Button-1>", lambda e, url = url : self.open_url(url))
            #     self.label_list.append(url_label)
            self.cosine_data, self.pagerank_data = use.search(search_string, self.InvertedIndex, self.document_lengths,
                              self.maxcount_dict, self.dict_url, self.pagerank,
                              self.sorted_dict)
            print(self.data)
            if self.is_pagerank_use:
                self.data = self.pagerank_data
            else:
                self.data = self.cosine_data
                
            self.draw_labels()
            # for index, url in enumerate(data):
            #     url_label = tk.Label(self, text = str(index) + ". " + url)
            #     url_label.pack()
            #     url_label.bind("<Button-1>", lambda e, url = url : self.open_url(url))
            #     self.label_list.append(url_label)
            
    def search_button_action_enter_button(self, event):
        for label in self.label_list:
            label.pack_forget()
        search_string = self.entry.get()
        print(search_string)
        if len(search_string) > 0:
            self.cosine_data, self.pagerank_data = use.search(search_string, self.InvertedIndex, self.document_lengths,
                              self.maxcount_dict, self.dict_url, self.pagerank,
                              self.sorted_dict)
            print(self.data)
            if self.is_pagerank_use:
                self.data = self.pagerank_data
            else:
                self.data = self.cosine_data
                
            self.draw_labels()
        
    def next_button_action(self):
        if len(self.data) > ((self.current_page_index + 1) * self.elems_per_page):
            self.current_page_index += 1
            self.draw_labels()
    
    def prev_button_action(self):
        if self.current_page_index > 0:
            self.current_page_index -= 1
            self.draw_labels()
        pass
    
    def draw_labels(self):
        for label in self.label_list:
            label.pack_forget()
        
        for index, url in enumerate(self.data):
            if index >= (self.current_page_index * self.elems_per_page) and index < ((self.current_page_index + 1) * self.elems_per_page):
                    
                url_label = tk.Label(self, text = str(index) + ". " + url)
                url_label.pack()
                url_label.bind("<Button-1>", lambda e, url = url : self.open_url(url))
                self.label_list.append(url_label)
    
    def open_url(self, url):
        webbrowser.open_new(url)
    
    def checkbox_action(self):
        if self.checkbox_val.get() == 0:
            self.is_pagerank_use = False
            self.data = self.cosine_data
        else: 
            self.is_pagerank_use = True
            self.data = self.pagerank_data
        
        self.draw_labels()
            
            
        

app = Search_Gui()
app.geometry("800x800")
app.mainloop()



