#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import ast
import nltk
from nltk.stem import PorterStemmer
import os
import re
import string
from collections import Counter
import numpy as np
import math
import sys
import json
import operator
import collections

json_data = []
save_relevants = []
count_terms=[]

stopwordsLocation = "stopwords.txt"

def getStopWordsList(fileLocation):##get the stop words from a file
    stopwords = []
    with open(fileLocation,'rb') as file:
        for line in file:
            word = line.decode("utf-8")
            stopwords.append(word.strip('\n'))
    return stopwords


def Tokenize_single_text(text):#tokenize a signle text
    text = nltk.word_tokenize(text)
    return text

def Clean_Single_Text(text):#clean a single text in one file
    text = str(text)
    text = text.lower()
    text = ''.join([i for i in text if not i.isdigit()])
    regex = re.compile(r'<.*?>')
    text = text.replace("'", "")
    text = text.replace(":", "")
    text = re.sub(regex, '', text)
    text = text.translate(str.maketrans(string.punctuation,' '*len(string.punctuation)))
    return text

def Stem_single_text(tokens):#stem all the tokens in one file
    stemmer = PorterStemmer()
    stemmedTokens = []
    for token in tokens:
        stemmed = stemmer.stem(token)
        if len(stemmed) > 2:
            stemmedTokens.append(stemmed)
    return stemmedTokens

def Remove_stop_words_single_text(tokens):
    s = getStopWordsList(stopwordsLocation)#location of the stopwords list file
    stopwords = []
    stemmer = PorterStemmer()
    for word in s:
        stopwords.append(stemmer.stem(word))#stemmed because they will be removed from the stemmed version of the tokens
    filteredTokens = []
    for token in tokens:
        if token not in stopwords:
            filteredTokens.append(token)
    return filteredTokens


def PreProcess_single_text(text, withStemAndStopwordsRemovalFlag):#clean, tokenize, remove stop words from a sinle text
    text = Clean_Single_Text(text)
    tokens = Tokenize_single_text(text)
    if withStemAndStopwordsRemovalFlag == 1:
        tokens = Stem_single_text(tokens)
        tokens = Remove_stop_words_single_text(tokens)
    return np.asarray(tokens)


def build_Index(preProcessed_tokens): #build the inverted index incrementally
    InvertedIndex = {}
    for i in range(0,len(preProcessed_tokens)):
        for token in preProcessed_tokens[i]:
            if token not in InvertedIndex:#if token already not in index, create new entry in hashtable
                InvertedIndex[token] = {}
            dictForToken = InvertedIndex[token]
            if i in dictForToken:#counting df
                dictForToken[i] +=1
            else:
                dictForToken[i] = 1
            InvertedIndex[token] = dictForToken
    return InvertedIndex

def built_document_hash_table(InvertedIndex, preProcessed_tokens):#calculated document length based on tfidf
    document_length = {}
    for i in range(0,len(preProcessed_tokens)):#looping through documents
        document_length[i] = 0
        for token in preProcessed_tokens[i]:
            countOfTerms = Counter(preProcessed_tokens[i])
            maximum = countOfTerms.most_common(1)
            term,maxCount = maximum[0]
            tf = InvertedIndex[token][i]/maxCount
            idf = math.log2(len(preProcessed_tokens)/len(InvertedIndex[token]))
            document_length[i]+=(tf*idf)*(tf*idf)

    for i in range(0,len(preProcessed_tokens)):
        document_length[i] = math.sqrt(document_length[i])

    return document_length

def get_preProcessed_queries(x):#get preprocessed queries
    preProcessed_queries = []
    singlelist=x.split()
    for single in singlelist:        
        query = str(single)
        query = query
        queryTokens = PreProcess_single_text(query,1)
        preProcessed_queries.append(queryTokens)
    return preProcessed_queries


def get_document_relevance_score(InvertedIndex, query, maxcount_dict, document_lengths, retrievaNumber):#retrieve documents based on one query and number of documents to retreive
    potential_relevants = {}
    queryDict = Counter(query)
    for token in queryDict:
        try:
            dictionary = InvertedIndex[token]
            for docID in dictionary.keys():
                maxCount = maxcount_dict[docID]
                tf = dictionary[docID]/maxCount
                idf = math.log2(5909/len(dictionary))
#                 print(len(preProcessed_tokens))
                maximum_q = queryDict.most_common(1)
                t, maxCount_q = maximum_q[0]
                tf_query = queryDict[token]/maxCount_q
                if docID in potential_relevants:
                    potential_relevants[docID]+= (tf*idf)*(idf*tf_query)
                else:
                    potential_relevants[docID]= (tf*idf)*(idf*tf_query)
        except:
            pass
    for docID in potential_relevants.keys():
        potential_relevants[docID] = potential_relevants[docID]/document_lengths[docID]
    potential_relevants = sorted(potential_relevants.items(), key=lambda x: x[1], reverse=True)
    save_relevants=potential_relevants
    return potential_relevants[0:retrievaNumber]

def get_relevant_documents(InvertedIndex, queryList, preProcessed_tokens, document_lengths, retrievaNumber):
    #get the specific number of relevant documents for all query 
    queryIDs = []
    docID = []
    for i in range(0,len(queryList)):
        relevant_docs = get_document_relevance_score(InvertedIndex, queryList[i], preProcessed_tokens, document_lengths, retrievaNumber)
        for doc, score in relevant_docs:
            queryIDs.append(i+1)
            docID.append(doc)
    return docID, relevant_docs

# preProcessed_tokens2=np.load('D://IR/TF-IDF/lastnp.npy')

def search(x, InvertedIndex, document_lengths, maxcount_dict, dict_url, pagerank, sorted_dict, is_page_rank_sort = False):
    print("Started")
    
    
    # print('Enter your query:')
    # x = input()
    preProcessed_queries = get_preProcessed_queries(x)
    
    # print('Top 10 documents: ')
    retrieved, save_relevants = get_relevant_documents(InvertedIndex, preProcessed_queries, maxcount_dict, document_lengths, 50)
     
    # file_inverted_index.close()
    # file_doc_length.close()
    # dict_doc.close()
    # file_pagerank.close()
    # file_maxcount.close()
    
    page_rank_dict={}
    for docid in retrieved:
        if docid in sorted_dict and docid in dict_url:
            page_rank_dict[dict_url[docid]]= sorted_dict[docid] 
    
    sorted_y = sorted(page_rank_dict.items(), key=operator.itemgetter(1), reverse=True)
    sorted_rank = collections.OrderedDict(sorted_y)
    # print('Pagerank: ')
    page_rank_list = []
    for url, rank in sorted_rank.items():
        page_rank_list.append(url)
        
    # return 


    
    result = []
    for docid in retrieved:
        if docid in dict_url:
            result.append(dict_url[docid])
            # print(dict_url[docid])
    # result = list(set(result))
    return result, page_rank_list
            
    
    
    # print("print cosine similarity score")
    # for i in save_relevants:       
    #     print(i[1])
    
    # print("page rank scores of the pages retrieved from cosine similarity score")
    # for docid in retrieved:
    #     if docid in sorted_dict and docid in dict_url:
    #         print(dict_url[docid], sorted_dict[docid] )
    
    
    # file_inverted_index.close()
    # file_doc_length.close()
    # dict_doc.close()
    # file_pagerank.close()
    # file_maxcount.close()
    
    print('\n')


